# viva-viager-media
Bun static image host. Serves /p/01.jpg .. /p/10.jpg.
