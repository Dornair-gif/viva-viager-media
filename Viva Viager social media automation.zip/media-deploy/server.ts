const PORT = process.env.PORT || 3000;
Bun.serve({
  port: PORT,
  async fetch(req) {
    const u = new URL(req.url);
    const m = u.pathname.match(/^\/p\/(\d{2})\.jpg$/);
    if (m) {
      const f = Bun.file("./img/" + m[1] + ".jpg");
      if (await f.exists()) {
        return new Response(f, {
          headers: {
            "Content-Type": "image/jpeg",
            "Cache-Control": "public, max-age=31536000, immutable",
            "Access-Control-Allow-Origin": "*"
          }
        });
      }
    }
    if (u.pathname === "/") {
      return new Response("<h1>Viva Viager media</h1>", { headers: { "Content-Type": "text/html" } });
    }
    return new Response("Not found", { status: 404 });
  }
});
console.log("media up on " + PORT);
